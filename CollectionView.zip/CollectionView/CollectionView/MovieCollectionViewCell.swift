//
//  MovieCollectionViewCell.swift
//  CollectionView
//
//  Created by Student on 4/25/22.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var ImageViewOutlet: UIImageView!
    func assignMovie(with movie:
                     Movie){
        ImageViewOutlet.image = movie.image
    }
    
    
}
