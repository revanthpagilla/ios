//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Student on 4/25/22.
//

import UIKit
class Product{
    var productName : String?
    var prodCategory : String?
    
    init(prodName:String, prodCategory:String){
        self.productName = prodName
        self.prodCategory = prodCategory
    }
}
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = TableViewOutlet.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        cell.textLabel?.text = productArray[indexPath.row].productName
        return cell
    }
    
    
    var productArray = [Product]()
    
    @IBOutlet weak var TableViewOutlet: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        TableViewOutlet.delegate = self
        TableViewOutlet.dataSource = self
        
        let p1 = Product(prodName: "Macbook", prodCategory: "Lappy")
        productArray.append(p1)
        
        let p2 = Product(prodName: "iphone", prodCategory: "phone")
        productArray.append(p2)
        
        let p3 = Product(prodName: "iwatch", prodCategory: "watch")
        productArray.append(p3)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
            if transition == "AppleProductDescription"{
            let destination = segue.destination as! ResultViewController
                
                destination.product = productArray[(TableViewOutlet.indexPathForSelectedRow?.row)!]
        }
    }

}

